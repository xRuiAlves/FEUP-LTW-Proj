</div>
        <footer>
            Developed by Filipa Durão, Henrique Lima and Rui Alves<br>Some rights reserved, 2018
        </footer>
</body>
</html>