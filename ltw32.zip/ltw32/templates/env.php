<?php
    $_env_website_name = "Traveler";
    $_env_login = "Log in";
    $_env_root_path = "/ROOT_PATH/";
?>